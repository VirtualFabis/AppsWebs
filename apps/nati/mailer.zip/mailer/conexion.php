<?php 

//conexion local

$cnx = mysqli_connect("localhost","id14901891_natalianeri","Pedazodeayer_05","id14901891_db_burocredito") or die("Error de conexion");

//conexion remota

#$cnx = mysqli_connect("localhost", "id13771772_alexis", "Aa123456789###", "id13771772_db_agenda") or die ("Error de conexión");


 ?>